﻿# -*- coding: utf-8 -*-

titles = ('1111', '2222', '3333', '4444', '5555', '6666', '7777', '8888')
catfiles = ('_1.ipg', '_2.ipg', '_3.ipg', '_4.ipg', '_5.ipg', '_6.ipg', '_7.ipg', '_8.ipg')
titles = ('Кухни "Классика"', 'Кухни "Модерн"', 'Шкафы-купе', 'Прихожие', 'Гостиные', 'Офисная', 'Детские', 'Разное')
mebcat = (u'Кухня классика', 'Кухня модерн', 'Шкаф-купе', 'Прихожая', 'Гостиная', 'Офис', 'Детская', 'Разное')


import fnmatch
prjpath = 'c:/_projects'
import os
import urllib

a='Andrey%20Bolohov/%D0%9A%D1%83%D1%85%D0%BD%D1%8F%20%D0%BA%D0%BB%D0%B0%D1%81%D1%81%D0%B8%D0%BA%D0%B0'
print a
s = urllib.unquote(a)
print s
u = s.decode('utf-8')
print u


'''
 	U32, utf32 	all languages
utf_32_be 	UTF-32BE 	all languages
utf_32_le 	UTF-32LE 	all languages
utf_16 	U16, utf16 	all languages
utf_16_be 	UTF-16BE 	all languages (BMP only)
utf_16_le 	UTF-16LE 	all languages (BMP only)
utf_7 	U7, unicode-1-1-utf-7 	all languages
utf_8 	U8, UTF, utf8 	all languages
utf_8_sig

'''