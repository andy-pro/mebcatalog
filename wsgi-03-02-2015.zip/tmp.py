﻿check=''
for arg in params:
    value=arg.split('=')
    if value[0]=='cat':
        arglist.append(value[1])
        check = value[0]
    if value[0]=='dir':
        arglist.append(value[1])
        check = value[0]
    if value[0]=='file':
        arglist.append(value[1])
        check = value[0]
print arglist, check