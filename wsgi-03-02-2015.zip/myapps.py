﻿def not_found(environ, start_response):
    start_response('404 Not Found', [('content-type','text/html')])
    return ["""<html><h1>Page not Found</h1><p>
               That page is unknown. Return to 
               the <a href="/">home page</a></p>
               </html>""",]  
               
def one(environ, start_response):
    start_response('200 OK', [('content-type','text/html')])
    return [templating.load_page({'content': 'The Content Of Page One'}, "one.html"),]

def two(environ, start_response):
    start_response('200 OK', [('content-type','text/html')])
    return [templating.load_page({'content': 'The Content Of Page Two'}, "one.html"),]

def index(environ, start_response):
    start_response('200 OK', [('Content-type', 'text/plain')])
    return ['Hello, world!']
