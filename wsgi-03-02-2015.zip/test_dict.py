# -*- coding: utf-8 -*-
query='cat=0&dir=agsvdhedy&file=122309'
#query='cat=0&dir=agsvdhedy'
#query='cat=0'
#query=''
if True:
    querylist = {}
    querynames = ['cat', 'dir', 'file']
    args = query.split('&')
    check = 0
    if len(args) > 0:
        for arg in args:
            value = arg.split('=')
            if value[0] in querynames:
                querylist[value[0]] = value[1]
                check = check + 1

print args, querylist, check


from pprint import pprint
s=query.replace('&', ',')
print s

s1 = 'id=1948,name=10,size=3'
s2=s1.split(',')
print s2
for i in s2:
    print i
d2 = dict(id=1948, name="Washer", size=3)
#d2=dict(s2)

#d2=dict((k,v) for k,v in s2)
#for k,v in s2:
 #   print k
#d1 = dict(query)
#print d2