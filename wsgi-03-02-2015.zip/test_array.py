﻿# -*- coding: utf-8 -*-
import urllib, os, glob, re
s='%D0%96%D0%B5%D0%BD%D1%8F%20%D0%9A%D0%BE%D1%81%D1%82%D1%8B%D0%BB%D0%B5%D0%B2%20%D0%AF%D1%81%D0%B8%D0%BD%D0%BE%D0%B2%D0%B0%D1%82%D0%B0%D1%8F/%D0%9A%D1%83%D1%85%D0%BD%D1%8F%20%D0%BA%D0%BB%D0%B0%D1%81%D1%81%D0%B8%D0%BA%D0%B0'
mymasktb = r'\thumbnails\*.jpg'
prjpath = urllib.unquote(s)
prjroot = r'c:\_projects'
#print prjpath
s=prjpath.decode('utf-8')
#print s
k = os.path.join(prjroot, s) + mymasktb
#print k
#basedict['arrayhrefimg'] = k
#s = unicode(k, 'utf-8')
s=k
#print s
thumbnails = glob.glob(s)
tb = thumbnails[10]
tbfile = tb.replace('\\', '/')
print tb
parts = re.split(r'[\\/]', tb)
tbfile = os.path.join(*parts[2:])
s = tbfile.replace('\\', '/')
#arrayimg.append(s.encode('utf-8'))
tbfile = os.path.join(parts[2], parts[3], 'images', parts[5])
print tbfile