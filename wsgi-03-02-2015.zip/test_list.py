path='mebcatalog/cat=0&dir=agsvdhedy&file=122309'
#path='mebcatalog/cat=0&dir=agsvdhedy'
#path='mebcatalog/cat=0'
#path='mebcatalog/'
#path='mebcatalog'
#path=''
if True:
    params = path.split('/')
    arglist = params[:]
    check = 0
    if len(params) > 1:
        args = params[1].split('&')
        for arg in args:
            value = arg.split('=')
            if value[0] == 'cat':
                arglist.append(value[1])
                check = check + 1
            if value[0] == 'dir':
                arglist.append(value[1])
                check = check + 1
            if value[0] == 'file':
                arglist.append(value[1])
                check = check + 1

print arglist, check

