﻿# -*- coding: utf-8 -*-
#from basetypes import output
import fnmatch
import sys
def application(environ, start_response):
    start_response('200 OK', [('content-type', 'text/html')])
    output = '''<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-language" content="ru" />
<meta http-equiv="Content-Type" content="txt/html; charset=utf-8" />
<title>Галерея</title>
<link rel="shortcut icon" href="/static/favicon.ico" type="image/ico" />
<link rel="stylesheet" href="/static/css/style.css" type="text/css" />
</head>
<body>

<h1>Hello</h1>
<img alt="" src="thumbnails/_IMGP0008.jpg" />
<div class="popup photo_win">
	<a class="close" href="#">Close</a>
	<h2>Привет питон</h2>
	<div class="img_wrap">
		<img alt="" src="/media/img_2.jpg" />
		<img alt="" src="/media/img_3.jpg" />
		<img alt="" src="/media/img_4.jpg" />
		<img alt="" src="media/img_2.jpg" />
		<img alt="" src="media/img_3.jpg" />				
		<img alt="" src="media/img_4.jpg" />				
	</div>
</div>
</body>
</html>
'''
    return [output]
    


def application(environ, start_response):
    start_response('200 OK', [('Content-type', 'text/plain')])
    return ['Hello, world!']

#------------------------------------------------------------------------

def application(environ, start_response):
    status = '200 OK' 
    output = 'Hello World!'

    response_headers = [('Content-type', 'text/plain'), ('Content-Length', str(len(output)))]
    start_response(status, response_headers)

    return [output]

#------------------------------------------------------------------------

def application(environ, start_response):
    #setup_testing_defaults(environ)     # working also without this line

    status = '200 OK'
    headers = [('Content-type', 'text/plain')]

    start_response(status, headers)

    ret = ["%s: %s\n" % (key, value)
           for key, value in environ.iteritems()]
    return ret

#------------------------------------------------------------------------

def application(environ, start_response):
    #start_response('200 OK', [('Content-type', 'text/plain')])
    #start_response('200 OK', [('Content-type', 'text/html; charset=utf-8')])
    start_response('200 OK', [('content-type', 'text/html')])
    return [

<html>
<head>
<title>Test</title>
</head>
<body>
<h1>Hello</h1>
<img alt="" src="thumbnails/_IMGP0008.jpg" />
<div class="popup photo_win">
	<a class="close" href="#">Close</a>
	<h2>Галерея</h2>
	<div class="img_wrap">
		<img alt="" src="images/img_2.jpg" />
		<img alt="" src="images/img_3.jpg" />
		<img alt="" src="images/img_4.jpg" />
		<img alt="" src="images/img_2.jpg" />
		<img alt="" src="images/img_3.jpg" />				
		<img alt="" src="images/img_4.jpg" />				
	</div>
</div>
</body>
</html>
            ]

